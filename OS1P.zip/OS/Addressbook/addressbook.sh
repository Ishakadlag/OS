#!/bin/sh

create() {
    touch addressbook.txt
}

insert() {
    echo "Enter a name:"
    read name
    echo "Enter an address:"
    read address
    echo "Enter phone number:"
    read phoneno
    echo "Enter email ID:"
    read email

    echo "$name $address $phoneno $email" >> addressbook.txt
}

view() {
    echo "Contents of the address book:"
    echo "Name Address Phone Email"
    cat addressbook.txt
}

modify() {
    echo "Enter the name you want to modify:"
    read name
    grep -v "^$name " addressbook.txt > addressbook1.txt
    mv addressbook1.txt addressbook.txt

    echo "Enter a name:"
    read name
    echo "Enter an address:"
    read address
    echo "Enter phone number:"
    read phoneno
    echo "Enter email ID:"
    read email

    echo "$name $address $phoneno $email" >> addressbook.txt
}

delete() {
    echo "Enter the name you want to delete:"
    read name
    grep -v "^$name " addressbook.txt > addressbook1.txt
    mv addressbook1.txt addressbook.txt
}

n=0
while [ $n -ne 6 ]; do
    echo "Enter your choice:"
    echo "1. Create"
    echo "2. Insert"
    echo "3. View"
    echo "4. Modify"
    echo "5. Delete"
    echo "6. Exit"
    read ch
    case $ch in
        "1") create ;;
        "2") insert ;;
        "3") view ;;
        "4") modify ;;
        "5") delete ;;
        "6") exit ;;
        *) echo "Invalid choice. Please try again." ;;
    esac
done
