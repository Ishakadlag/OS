#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>

void bubble_sort(int [], int);
void bubble_sort_2(int [], int);

int main() {
    int array[100], n, c;
    
    printf("Enter number of elements: ");
    scanf("%d", &n);
    printf("Enter %d numbers:\n", n);
    for (c = 0; c < n; c++) {
        scanf("%d", &array[c]);
    }

    // Create a copy of the array for the parent process
    int array_copy[100];
    for (c = 0; c < n; c++) {
        array_copy[c] = array[c];
    }

    pid_t pid = fork();

    if (pid < 0) {
        // Error handling for fork failure
        perror("Fork failed");
        return 1;
    }

    if (pid == 0) {
        // Child process
        printf("Hello, I am the Child process\n");
        bubble_sort(array, n);
        printf("Sorted list in ascending order:\n");
        for (c = 0; c < n; c++) {
            printf("%d\n", array[c]);
        }
    } else {
        // Parent process
        printf("Hello, I am the Parent process\n");
        bubble_sort_2(array_copy, n);
        printf("Sorted list in descending order:\n");
        for (c = 0; c < n; c++) {
            printf("%d\n", array_copy[c]);
        }
    }
    
    return 0;
}

void bubble_sort(int list[], int n) {
    int c, d, t;
    for (c = 0; c < (n - 1); c++) {
        for (d = 0; d < n - c - 1; d++) {
            if (list[d] > list[d + 1]) {
                // Swapping
                t = list[d];
                list[d] = list[d + 1];
                list[d + 1] = t;
            }
        }
    }
}

void bubble_sort_2(int list[], int n) {
    int c, d, t;
    for (c = 0; c < (n - 1); c++) {
        for (d = 0; d < n - c - 1; d++) {
            if (list[d] < list[d + 1]) {
                // Swapping
                t = list[d];
                list[d] = list[d + 1];
                list[d + 1] = t;
            }
        }
    }
}
