#include <stdio.h>
#include <stdlib.h>

int binary(int a[], int n, int m, int l, int u) {
    if (l <= u) {
        int mid = (l + u) / 2;
        if (m == a[mid]) {
            return 1;  // Number found
        } else if (m < a[mid]) {
            return binary(a, n, m, l, mid - 1);
        } else {
            return binary(a, n, m, mid + 1, u);
        }
    }
    return 0;  // Number not found
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: ./s1 <sorted_numbers...>\n");
        return 1;
    }

    int nEle = argc - 1;
    int a[nEle];
    int i;

    // Convert arguments to integers
    for (i = 0; i < nEle; i++) {
        a[i] = atoi(argv[i + 1]);
        printf("a[%d] = %d\n", i, a[i]);
    }

    int x;
    printf("Please enter the element to search using binary search:\n");
    scanf("%d", &x);

    int result = binary(a, nEle, x, 0, nEle - 1);
    if (result == 0) {
        printf("Number is not found.\n");
    } else {
        printf("Number is found.\n");
    }

    return 0;
}
