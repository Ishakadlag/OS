#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <wait.h>

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: ./f1 <program_name> <number1> <number2> ...\n");
        return 1;
    }

    int nEle = argc - 2;
    int elem, temp, pid;
    char *args[nEle + 2];  // Extra space for NULL termination
    int i, j;
    int a[nEle];

    // Set the name of the second program to execute
    args[0] = argv[1];
    for (i = 1; i <= nEle; i++) {
        a[i - 1] = atoi(argv[i + 1]);  // Convert command line arguments to integers
    }

    // Sorting the array
    for (i = 0; i < nEle - 1; i++) {
        for (j = i + 1; j < nEle; j++) {
            if (a[i] > a[j]) {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }

    printf("\nSorted Array:\n");
    for (i = 0; i < nEle; i++) {
        printf("%d\n", a[i]);
    }

    // Convert sorted integers to strings and store them in args[]
    for (i = 0; i < nEle; i++) {
        args[i + 1] = (char *)malloc(10 * sizeof(char));
        sprintf(args[i + 1], "%d", a[i]);
    }
    args[nEle + 1] = NULL;  // NULL termination for execv

    pid = fork();  // Create a child process
    if (pid == 0) {
        // Child process executes the second program
        printf("\nNow child is executing %s with sorted array\n", args[0]);
        execv(args[0], args);
        perror("execv failed");  // If execv fails, print error
        exit(1);
    } else if (pid > 0) {
        // Parent process waits for the child
        wait(NULL);
    } else {
        perror("fork failed");
        return 1;
    }

    // Free allocated memory
    for (i = 0; i < nEle; i++) {
        free(args[i + 1]);
    }

    return 0;
}
