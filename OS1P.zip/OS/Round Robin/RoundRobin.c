#include <stdio.h>
#include <stdlib.h>

int main() {
    int i, NOP, sum = 0, count = 0, y, quant, wt = 0, tat = 0;
    int at[10], bt[10], temp[10];
    float avg_wt, avg_tat;

    // Get total number of processes
    printf("Total number of processes in the system: ");
    scanf("%d", &NOP);
    y = NOP; // Copy the number of processes to `y`

    // Input arrival time and burst time for each process
    for (i = 0; i < NOP; i++) {
        printf("\nEnter the Arrival and Burst time of the Process[%d]\n", i + 1);
        printf("Arrival time is:\t");
        scanf("%d", &at[i]);
        printf("Burst time is:\t");
        scanf("%d", &bt[i]);
        temp[i] = bt[i]; // Store burst time in `temp` for processing
    }

    // Input time quantum
    printf("Enter the Time Quantum for the process:\t");
    scanf("%d", &quant);

    // Print the header for the output table
    printf("\n%-10s %-15s %-15s %-15s\n", "Process No", "Burst Time", "(TAT)", "Waiting Time (WT)");

    // Round Robin scheduling logic
    for (sum = 0, i = 0; y != 0; ) {
        if (temp[i] <= quant && temp[i] > 0) { // Process execution less than or equal to quantum
            sum += temp[i];
            temp[i] = 0;
            count = 1;
        } else if (temp[i] > 0) { // Process execution greater than quantum
            temp[i] -= quant;
            sum += quant;
        }

        if (temp[i] == 0 && count == 1) { // Process is fully executed
            y--; // Decrement process count
            // Print the process details in a formatted way
            printf("P%-10d %-15d %-15d %-15d\n", i + 1, bt[i], sum - at[i], sum - at[i] - bt[i]);
            wt += sum - at[i] - bt[i]; // Accumulate waiting time
            tat += sum - at[i]; // Accumulate turn-around time
            count = 0;
        }

        // Move to the next process
        if (i == NOP - 1) {
            i = 0;
        } else if (at[i + 1] <= sum) {
            i++;
        } else {
            i = 0;
        }
    }

    // Calculate average waiting time and average turn-around time
    avg_wt = (float) wt / NOP;
    avg_tat = (float) tat / NOP;

    // Calculate the maximum width for the waiting time column dynamically
    int max_wt = wt / NOP;  // Using the average waiting time as an estimate for max width
    int max_tat = tat / NOP; // Using the average turnaround time as an estimate for max width
    int width = (max_tat > max_wt) ? max_tat : max_wt;

    // Print average waiting time and turnaround time
    printf("\nAverage Turn Around Time:\t%*d", width, (int)avg_tat);
    printf("\nAverage Waiting Time:\t%*d\n", width, (int)avg_wt);

    return 0;
}
