#include<stdio.h>
#include<stdlib.h>

void FIFO(char[], char[], int, int);
void lru(char[], char[], int, int);
void opt(char[], char[], int, int);

int main() {
    int ch, YN = 1, i, l, f;
    char F[10], s[25];
    
    // Clear screen (UNIX system)
    system("clear");
    
    printf("\n\n\tEnter the no of empty frames: ");
    scanf("%d", &f);
    printf("\n\n\tEnter the length of the string: ");
    scanf("%d", &l);
    printf("\n\n\tEnter the string: ");
    scanf("%s", s);
    
    // Initialize frames with -1
    for (i = 0; i < f; i++)
        F[i] = -1;

    do {
        // Clear screen (UNIX system)
        system("clear");
        
        // Menu display
        printf("\n\n\t*********** MENU ***********");
        printf("\n\n\t1:FIFO\n\n\t2:LRU\n\n\t3:OPT\n\n\t4:EXIT");
        printf("\n\n\tEnter your choice: ");
        scanf("%d", &ch);
        
        // Clear screen (UNIX system)
        system("clear");

        switch (ch) {
            case 1:
                for (i = 0; i < f; i++) {
                    F[i] = -1;
                }
                FIFO(s, F, l, f);
                break;

            case 2:
                for (i = 0; i < f; i++) {
                    F[i] = -1;
                }
                lru(s, F, l, f);
                break;

            case 3:
                for (i = 0; i < f; i++) {
                    F[i] = -1;
                }
                opt(s, F, l, f);
                break;

            case 4:
                exit(0);
        }

        // Continue loop if the user chooses to
        printf("\n\n\tDo u want to continue IF YES PRESS 1\n\n\tIF NO PRESS 0 : ");
        scanf("%d", &YN);

    } while (YN == 1);

    return 0;
}

// FIFO (First-In-First-Out)
void FIFO(char s[], char F[], int l, int f) {
    int i, j = 0, k, flag = 0, cnt = 0;
    printf("\n\tPAGE\t    FRAMES\t  FAULTS");
    
    for (i = 0; i < l; i++) {
        flag = 0;
        // Check if page is already in frame
        for (k = 0; k < f; k++) {
            if (F[k] == s[i]) {
                flag = 1;
                break;
            }
        }

        // If page is not found, replace the page in FIFO order
        if (flag == 0) {
            F[j] = s[i];
            j = (j + 1) % f;
            cnt++;
        }

        // Print current page and frame status
        printf("\n\t%c\t", s[i]);
        for (k = 0; k < f; k++) {
            printf("   %c", F[k] == -1 ? ' ' : F[k]);
        }
        printf("\t%s", flag == 0 ? "Page-fault" : "No page-fault");
    }
}

// LRU (Least Recently Used)
void lru(char s[], char F[], int l, int f) {
    int i, j = 0, k, m, flag = 0, cnt = 0, top = 0;
    int last_used[10] = {0}; // Track last use time for LRU
    printf("\n\tPAGE\t    FRAMES\t  FAULTS");

    for (i = 0; i < l; i++) {
        flag = 0;
        // Check if page is already in frame
        for (k = 0; k < f; k++) {
            if (F[k] == s[i]) {
                flag = 1;
                last_used[k] = i; // Update last used time
                break;
            }
        }

        // If page is not found, replace the least recently used
        if (flag == 0) {
            int min_time = i, min_index = 0;
            // Find the least recently used page
            for (k = 0; k < f; k++) {
                if (last_used[k] < min_time) {
                    min_time = last_used[k];
                    min_index = k;
                }
            }
            F[min_index] = s[i];
            last_used[min_index] = i;
            cnt++;
        }

        // Print current page and frame status
        printf("\n\t%c\t", s[i]);
        for (k = 0; k < f; k++) {
            printf("   %c", F[k] == -1 ? ' ' : F[k]);
        }
        printf("\t%s", flag == 0 ? "Page-fault" : "No page-fault");
    }
}

// OPT (Optimal)
void opt(char s[], char F[], int l, int f) {
    int i, j = 0, k, m, flag = 0, cnt = 0, temp[10];
    printf("\n\tPAGE\t    FRAMES\t  FAULTS");

    for (i = 0; i < 10; i++)
        temp[i] = 0;

    for (i = 0; i < f; i++)
        F[i] = -1;

    for (i = 0; i < l; i++) {
        flag = 0;

        // Check if page is already in frame
        for (k = 0; k < f; k++) {
            if (F[k] == s[i]) {
                flag = 1;
                break;
            }
        }

        // If page is not found, replace using optimal page replacement
        if (flag == 0) {
            for (m = 0; m < f; m++) {
                for (k = i + 1; k < l; k++) {
                    if (F[m] != s[k]) {
                        temp[m]++;
                    } else {
                        break;
                    }
                }
            }

            // Replace the page with the farthest future use
            int max = 0, max_index = 0;
            for (m = 0; m < f; m++) {
                if (temp[m] > max) {
                    max = temp[m];
                    max_index = m;
                }
            }
            F[max_index] = s[i];
            cnt++;
        }

        // Print current page and frame status
        printf("\n\t%c\t", s[i]);
        for (k = 0; k < f; k++) {
            printf("   %c", F[k] == -1 ? ' ' : F[k]);
        }
        printf("\t%s", flag == 0 ? "Page-fault" : "No page-fault");

        // Reset the temp array
        for (k = 0; k < 10; k++)
            temp[k] = 0;
    }
}
