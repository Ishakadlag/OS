#include<stdio.h>
int main()
{
int n,i,bt[10],wt[10],tat[10],awt,atat;
printf("How many Elements you want to enter:");
scanf("%d",&n);
for(i=0;i<n;i++)
{
printf("Enter Burst time for P%d:",i);
scanf("%d",&bt[i]);
}
printf("\nProcess Details are:\n");
printf("Process\t Burst Time\n");
for(i=0;i<n;i++)
{
printf(" P%d\t %d\n",i,bt[i]);
}
printf("\n");
//Waiting Time
wt[0]=0;
for(i=0;i<n;i++)
{
wt[i+1]=wt[i]+bt[i];
printf("Waiting Time of P%d is %d\n",i,wt[i]);
}
printf("\n");
//Turn Around Time
for(i=0;i<n;i++)
{
tat[i]=bt[i]+wt[i];
printf("Turn Around Time of P%d is %d\n",i,tat[i]);
}
printf("\nProcess\t Burst Time\t Waiting Time\t Turn-Around Time\n");
for(i=0;i<n;i++){
printf(" P%d\t %d\t\t %d\t \t\t%d\n",i,bt[i],wt[i],tat[i]); }
awt=0;
atat=0;
for(i=0;i<n;i++)
{
awt=awt+wt[i];
atat+=tat[i];
}
printf("\nAverage Waiting Time: %d",(awt/n));
printf("\nAverage Turn Around Time: %d\n",(atat/n));
}

